require 'test_helper'

class QuoteHelperTest < ActionView::TestCase
end
