require 'test_helper'

class QuotesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
