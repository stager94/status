class Link < ActiveRecord::Base
  attr_accessible :path, :title
end
