ActiveAdmin.register Link do
  
end
