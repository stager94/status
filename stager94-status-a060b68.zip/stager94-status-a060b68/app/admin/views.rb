ActiveAdmin.register View do
  
end
