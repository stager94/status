ActiveAdmin.register Quote do
  
end
