ActiveAdmin.register Menu do
  
end
