ActiveAdmin.register Page do
  
end
