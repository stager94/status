ActiveAdmin.register Category do
  
  controller do
  	def new
  		
  	end
  end

  form do |f|
  	
    f.inputs
    f.buttons
  end
end
